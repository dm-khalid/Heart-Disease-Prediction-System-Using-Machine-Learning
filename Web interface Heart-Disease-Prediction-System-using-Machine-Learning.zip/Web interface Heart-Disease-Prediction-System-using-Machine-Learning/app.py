from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# Load the trained model
model = joblib.load("heart_model.pkl")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    feature_names = ['age', 'chest_pain', 'rest_blood_pressure', 'cholesterol', 'max_heart_rate', 'exercise_induced_angina', 'st_depression', 'st_slope', 'num_major_vessels', 'thalassaemia']
    input_data = [float(request.form[name]) for name in feature_names]
    prediction = model.predict([input_data])

    if prediction[0] == 0:
        result = "The Person does not have any Heart Disease"
    else:
        result = "The Person has Heart Disease"

    return render_template("index.html", result=result)

if __name__ == "__main__":
    app.run(debug=True)
